export class AgenticSense {
  constructor() {}
  detect() { return { faces: [], gestures: [], objects: [] }; }
}
export async function createPipeline() { return new AgenticSense(); }
